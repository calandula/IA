try:
    import networkx as nx
except:
    print('Package networkx not found.')
    print('Please run the following command:')
    print('  pip install networkx')
    exit()

import random
import math


VARIANCE = 0.1
LO = 1 - VARIANCE
HI = 1 + VARIANCE
FACTOR = 0.5
NEIGHBORS = 0.1
TRIES = 100
ROVERFUEL = 4


num_problema = 1


def gen(size):
    global num_problema

    # slots = size +- VARIANCE
    num_slots = random.randint(
    math.floor(LO * size),
    math.ceil(HI * size))
    # bases = FACTOR * slots * FACTOR +- VARIANCE
    num_bases = random.randint(
    math.ceil(LO * FACTOR * num_slots),
    math.ceil(HI * FACTOR * num_slots))
    # rovers = FACTOR * bases +- VARIANCE
    num_rovers = random.randint(
    math.ceil(LO * FACTOR * num_bases),
    math.ceil(HI * FACTOR * num_bases))
    # slots_personal = FACTOR * slots +- VARIANCE (slots_suministros = los restantes)
    num_slots_pers = random.randint(
    math.ceil(LO * FACTOR * num_slots),
    math.ceil(HI * FACTOR * num_slots))
    num_slots_sumi = num_slots - num_slots_pers
    slots_pers_first = 0
    slots_pers_last = slots_pers_first + num_slots_pers
    slots_sumi_first = num_slots_pers
    slots_sumi_last = slots_sumi_first + num_slots_sumi
    # recursos_personal = FACTOR * recursos +- VARIANCE (recursos_suministro = los restantes)
    num_personal = random.randint(
    math.ceil(LO * FACTOR * num_slots_pers),
    math.ceil(HI * FACTOR * num_slots_pers))
    num_suministros = random.randint(
    math.ceil(LO * FACTOR * num_slots_sumi),
    math.ceil(HI * FACTOR * num_slots_sumi))
    personal_first = 0
    personal_last = personal_first + num_personal
    suministros_first = num_personal
    suministros_last = suministros_first + num_suministros
    # bases_asentamiento = FACTOR * bases +- VARIANCE (bases_almacen = las restantes)
    num_asentamientos = random.randint(
    math.ceil(LO * FACTOR * num_bases),
    math.ceil(HI * FACTOR * num_bases))
    num_almacenes = num_bases - num_asentamientos
    asentamientos_first = 0
    asentamientos_last = asentamientos_first + num_asentamientos
    almacenes_first = num_asentamientos
    almacenes_last = almacenes_first + num_almacenes

    # generate graph
    G = nx.connected_watts_strogatz_graph(num_bases, max(2, math.ceil(NEIGHBORS * num_bases)), TRIES)

    # generate problem
    name = 'Ejemplo1-' + str(num_problema)
    print('Generando', name, '...')
    num_problema += 1
    with open(name + '.pddl', 'w') as of:
        of.write('(define (problem ' + name + ') (:domain Dominio_basico)\n')

        # Define objects
        of.write('(:objects\n  ')
        for ind in range(0, num_bases):
            of.write('B' + str(ind) + ' ')
        of.write('- base\n  ')
        for ind in range(0, num_rovers):
            of.write('R' + str(ind) + ' ')
        of.write('- rover\n  ')
        for ind in range(0, num_slots):
            of.write('S' + str(ind) + ' ')
        of.write('- slot\n)\n\n')

        of.write('(:init\n')
        # Define connected bases
        for node, adjs in G.adjacency():
            for neig, _ in adjs.items():
                of.write('  (basesConectadas B' + str(node) + ' B' + str(neig) + ')\n')
        of.write('\n')

        # Define initial rover position
        for rover in range(0, num_rovers):
            base = random.randint(0, num_bases-1)
            of.write('  (enBase R' + str(rover) + ' B' + str(base) + ')\n')
        of.write('\n')

        # Define initial personnel
        personas_restantes = num_personal
        for asentamiento in range(asentamientos_first, asentamientos_last):
            if asentamiento == asentamientos_last-1:
                num_personas = personas_restantes
            elif personas_restantes > 0:
                num_personas = random.randint(0, personas_restantes)
                personas_restantes -= num_personas
            else:
                num_personas = 0
            of.write('  (= (personasEnBase B' + str(asentamiento) + ') ' + str(num_personas) + ')\n')
        for almacen in range(almacenes_first, almacenes_last):
            of.write('  (= (personasEnBase B' + str(almacen) + ') 0)\n')
        of.write('\n')

        # Define initial supplies
        suministros_restantes = num_suministros
        for asentamiento in range(asentamientos_first, asentamientos_last):
            of.write('  (= (suministrosEnBase B' + str(asentamiento) + ') 0)\n')
        for almacen in range(almacenes_first, almacenes_last):
            if almacen == almacenes_last-1:
                num_suministros = suministros_restantes
            elif suministros_restantes > 0:
                num_suministros = random.randint(0, suministros_restantes)
                suministros_restantes -= num_suministros
            else:
                num_suministros = 0
            of.write('  (= (suministrosEnBase B' + str(almacen) + ') ' + str(num_suministros) + ')\n')
        of.write('\n')
        of.write('  (= (recursosDisponibles) ' + str(num_personal + num_suministros) + ')')
        of.write('\n')

        # Define initial rover load
        for rover in range(0, num_rovers):
            of.write('  (= (contieneRoverPersonas R' + str(rover) + ') 0)\n')
        for rover in range(0, num_rovers):
            of.write('  (= (contieneRoverSuministros R' + str(rover) + ') 0)\n')
        of.write('\n')

        # Define initial rover fuel
        # for rover in range(0, num_rovers):
        #     of.write('  (= (gasolinaRover R' + str(rover) + ') ' + str(ROVERFUEL) + ')\n')
        # of.write('  (= (totalGasolina) ' + str(num_rovers * ROVERFUEL) + ')\n')
        # of.write('\n')

        # Define slot type, destination and priority
        for slot_pers in range(slots_pers_first, slots_pers_last):
            of.write('  (peticionPersonal S' + str(slot_pers) + ')\n')
            destinacion = random.randint(asentamientos_first, asentamientos_last-1)
            of.write('  (destinoPeticion S' + str(slot_pers) + ' B' + str(destinacion) + ')\n')
            prioridad = random.randint(1, 3)
            # of.write('  (= (prioridadPeticion S' + str(slot_pers) + ') ' + str(prioridad) + ')\n')
        for slot_sumi in range(slots_sumi_first, slots_sumi_last):
            of.write('  (peticionSuministro S' + str(slot_sumi) + ')\n')
            destinacion = random.randint(asentamientos_first, asentamientos_last-1)
            of.write('  (destinoPeticion S' + str(slot_sumi) + ' B' + str(destinacion) + ')\n')
            prioridad = random.randint(1, 3)
            # of.write('  (= (prioridadPeticion S' + str(slot_sumi) + ') ' + str(prioridad) + ')\n')
        # of.write('\n')
        # of.write('  (= (prioridadTotalServida) 0)\n')
        of.write(')\n')

        of.write('\n')

        # Define goal
        of.write('(:goal (= (recursosDisponibles) 0))\n')
        # of.write('(:metric maximize (+ (* (prioridadTotalServida) 2) (* (totalGasolina) 4)))\n)')
        of.write(')\n')

        of.close()


def main():
    size = 10
    for factor in range(0, 5):
        gen(size)
        size += 2


main()
